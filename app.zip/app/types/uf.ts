export class UF {
  id: number;
  nome: string;
  area: number
}
